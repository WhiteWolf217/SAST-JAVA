package com.sast;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class TestApp {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ScriptException {
        // VULNERABLE: Direct user input written to response without encoding
        String name = request.getParameter("name");
        response.getWriter().write("<h1>Hello " + name + "</h1>");

        // VULNERABLE: Another example using print
        response.getWriter().print("User input: " + request.getParameter("input"));

        // VULNERABLE: println method
        response.getWriter().println("Comment: " + request.getParameter("comment"));

        // VULNERABLE: Append method
        response.getWriter().append("Output: " + request.getParameter("output"));

        // VULNERABLE: Using ScriptEngine with user input (code injection risk)
        ScriptEngineManager manager = new ScriptEngineManager();
        ScriptEngine engine = manager.getEngineByName("JavaScript");
        String script = request.getParameter("script"); // user-controlled code
        engine.eval(script); // dangerous
    }
}
