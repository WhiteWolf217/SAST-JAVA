package com.sast;

import com.github.javaparser.*;
import com.github.javaparser.ast.*;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.stmt.*;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import java.io.File;
import java.io.IOException;
import java.util.Optional;
import java.util.Set;

public class SASTanalyzer {

    public static void main(String[] args) {
        System.out.println("SAST Security Analyzer starting...");
        
        if (args.length < 1) {
            System.out.println("Please provide the path to a Java file for analysis.");
            return;
        }

        String filePath = args[0];
        System.out.println("Analyzing file: " + filePath);
        
        SASTanalyzer analyzer = new SASTanalyzer();
        try {
            analyzer.analyze(filePath);
        } catch (Exception e) {
            System.out.println("Error during analysis: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void analyze(String javaFilePath) throws IOException {
        System.out.println("=== Starting security analysis of file: " + javaFilePath + " ===");
        
        File file = new File(javaFilePath);
        if (!file.exists()) {
            System.out.println("ERROR: File does not exist: " + javaFilePath);
            return;
        }
        
        JavaParser parser = new JavaParser();
        ParseResult<CompilationUnit> result = parser.parse(file);

        if (result.isSuccessful() && result.getResult().isPresent()) {
            CompilationUnit cu = result.getResult().get();
            
            System.out.println("\n[1/5] Running hardcoded password detection...");
            cu.accept(new HardcodedPasswordVisitor(), null);
            
            System.out.println("\n[2/5] Running SQL injection detection...");
            cu.accept(new SQLInjectionVisitor(), null);

            System.out.println("\n[3/5] Running buffer overflow detection...");
            cu.accept(new BufferOverflowVisitor(), null);

            System.out.println("\n[4/5] Running XSS detection...");
            cu.accept(new XSSVisitor(), null);

            System.out.println("\n[5/5] Running OS command injection detection...");
            cu.accept(new OSCommandInjectionVisitor(), null);
            
            System.out.println("\n=== Security analysis complete ===");
        } else {
            System.out.println("Failed to parse Java file: " + javaFilePath);
        }
    }

    // Hardcoded Password Detection
    private static class HardcodedPasswordVisitor extends VoidVisitorAdapter<Void> {
        private int vf = 0;
        
        @Override
        public void visit(CompilationUnit cu, Void arg) {
            super.visit(cu, arg);
            System.out.println("Hardcoded password vulnerabilities found: " + vf);
        }
        
        @Override
        public void visit(FieldDeclaration n, Void arg) {
            super.visit(n, arg);

            n.getVariables().forEach(variable -> {
                Optional<Expression> initializer = variable.getInitializer();
                checkInitializer(initializer, variable.getNameAsString(), "field", n.getBegin());
            });
        }

        @Override
        public void visit(VariableDeclarationExpr n, Void arg) {
            super.visit(n, arg);
            
            n.getVariables().forEach(variable -> {
                Optional<Expression> initializer = variable.getInitializer();
                checkInitializer(initializer, variable.getNameAsString(), "local variable", n.getBegin());
            });
        }
        
        private void checkInitializer(Optional<Expression> initializer, String variableName, 
                                     String variableType, Optional<Position> position) {
            if (initializer.isPresent() && initializer.get() instanceof StringLiteralExpr) {
                StringLiteralExpr stringExpr = (StringLiteralExpr) initializer.get();
                String value = stringExpr.getValue();
                
                boolean suspiciousName = variableName.toLowerCase().contains("password") || 
                                        variableName.toLowerCase().contains("pwd") ||
                                        variableName.toLowerCase().contains("secret") ||
                                        variableName.toLowerCase().contains("key");
                
                if (value.equals("12345") || 
                    value.equals("password") || 
                    value.equals("password123") ||
                    value.equals("1234567890") ||
                    value.equals("qwerty") ||
                    value.equals("admin") ||
                    (suspiciousName && value.length() > 0)) {
                    
                    
                    int lineNum = position.map(p -> p.line).orElse(-1);
                    System.out.println("[VULNERABILITY] Hardcoded password detected in " + 
                                     variableType + " \"" + variableName + 
                                     "\" at line " + lineNum);
                    System.out.println("  Value: \"" + value + "\"");
                    System.out.println("  Severity: HIGH");
                    System.out.println("  Risk: Exposing credentials in source code can lead to unauthorized access");
                    vf++;
                }
            }
        }
    }

    // SQL Injection Detection
    private static class SQLInjectionVisitor extends VoidVisitorAdapter<Void> {
        private int vf = 0;
        
        @Override
        public void visit(CompilationUnit cu, Void arg) {
            super.visit(cu, arg);
            System.out.println("SQL injection vulnerabilities found: " + vf);
        }
        
        @Override
        public void visit(VariableDeclarationExpr n, Void arg) {
            super.visit(n, arg);
            
            n.getVariables().forEach(variable -> {
                String varName = variable.getNameAsString().toLowerCase();
                Optional<Expression> initializer = variable.getInitializer();
                
                boolean isSqlVariable = varName.contains("sql") || 
                                      varName.contains("query") || 
                                      varName.contains("statement");
                
                if (isSqlVariable && initializer.isPresent()) {
                    checkSqlExpression(initializer.get(), variable.getNameAsString(), n.getBegin());
                }
            });
        }
        
        @Override
        public void visit(AssignExpr n, Void arg) {
            super.visit(n, arg);
            
            if (n.getTarget() instanceof NameExpr) {
                String varName = ((NameExpr) n.getTarget()).getNameAsString().toLowerCase();
                boolean isSqlVariable = varName.contains("sql") || 
                                      varName.contains("query") || 
                                      varName.contains("statement");
                                      
                if (isSqlVariable) {
                    checkSqlExpression(n.getValue(), varName, n.getBegin());
                }
            }
        }

        @Override
        public void visit(MethodCallExpr n, Void arg) {
            super.visit(n, arg);
            
            String methodName = n.getNameAsString().toLowerCase();
            boolean isSqlMethod = methodName.equals("executequery") || 
                                methodName.equals("executeupdate") || 
                                methodName.equals("execute") ||
                                methodName.equals("preparestatement");
            
            if (isSqlMethod && n.getArguments().size() > 0) {
                checkSqlExpression(n.getArgument(0), "SQL in " + methodName, n.getBegin());
            }
        }
        
        private void checkSqlExpression(Expression expr, String context, Optional<Position> position) {
            if (expr instanceof BinaryExpr) {
                BinaryExpr binExpr = (BinaryExpr) expr;
                if (binExpr.getOperator() == BinaryExpr.Operator.PLUS) {
                    int lineNum = position.map(p -> p.line).orElse(-1);
                    System.out.println("[VULNERABILITY] Potential SQL injection detected in \"" + 
                                     context + "\" at line " + lineNum);
                    System.out.println("  Issue: String concatenation in SQL query");
                    System.out.println("  Severity: HIGH");
                    System.out.println("  Fix: Use parameterized queries/prepared statements");
                    vf++;
                }
            }
            
            if (expr instanceof StringLiteralExpr) {
                StringLiteralExpr strExpr = (StringLiteralExpr) expr;
                String value = strExpr.getValue().toLowerCase();
                
                if ((value.contains("select") || value.contains("insert") || 
                     value.contains("update") || value.contains("delete")) && 
                    (value.contains("?") || value.contains(":"))) {
                    
                    int lineNum = position.map(p -> p.line).orElse(-1);
                    System.out.println("[INFO] Good practice: Parameterized SQL query detected at line " + lineNum);
                }
            }
        }
    }

    // Buffer Overflow Detection
    private static class BufferOverflowVisitor extends VoidVisitorAdapter<Void> {
        private int vf = 0;
        
        @Override
        public void visit(CompilationUnit cu, Void arg) {
            super.visit(cu, arg);
            System.out.println("Buffer overflow vulnerabilities found: " + vf);
        }
        
        @Override
        public void visit(MethodCallExpr n, Void arg) {
            super.visit(n, arg);
            
            String methodName = n.getNameAsString();
            if (methodName.equals("arraycopy")) {
                if (n.getArguments().size() >= 5) {
                    Expression sizeArg = n.getArgument(4);
                    if (isUnsafeSizeExpression(sizeArg)) {
                        reportVulnerability(n, "Unsafe System.arraycopy operation - length parameter might cause buffer overflow");
                    }
                }
            }
            
            if (methodName.equals("getBytes") || methodName.equals("getChars")) {
                if (n.getArguments().size() >= 4) {
                    Expression sizeArg = n.getArguments().get(3);
                    if (isUnsafeSizeExpression(sizeArg)) {
                        reportVulnerability(n, "Unsafe " + methodName + " operation - length parameter might cause buffer overflow");
                    }
                }
            }
        }
        
        @Override
        public void visit(ArrayAccessExpr n, Void arg) {
            super.visit(n, arg);
            
            if (n.getIndex() instanceof BinaryExpr) {
                BinaryExpr indexExpr = (BinaryExpr) n.getIndex();
                if (indexExpr.getOperator() == BinaryExpr.Operator.PLUS || 
                    indexExpr.getOperator() == BinaryExpr.Operator.MINUS) {
                    reportVulnerability(n, "Array access with arithmetic operation might lead to buffer overflow");
                }
            }
        }
        @Override
        public void visit(ForStmt n, Void arg) {
            super.visit(n, arg);

            Optional<Expression> condition = n.getCompare();
            if (condition.isPresent() && condition.get() instanceof BinaryExpr) {
                BinaryExpr binaryExpr = (BinaryExpr) condition.get();
                BinaryExpr.Operator op = binaryExpr.getOperator();

                if (op == BinaryExpr.Operator.LESS_EQUALS || op == BinaryExpr.Operator.GREATER_EQUALS) {
                    Expression right = binaryExpr.getRight();
                    if (right instanceof FieldAccessExpr || right.toString().contains(".length")) {
                        reportVulnerability(n, "Potential off-by-one error in loop condition may cause buffer overflow");
                    }
                }
            }
        }

        @Override
        public void visit(ArrayCreationExpr n, Void arg) {
            super.visit(n, arg);
            
            if (n.getLevels().size() > 0 && n.getLevels().get(0).getDimension().isPresent()) {
                Expression sizeExpr = n.getLevels().get(0).getDimension().get();
                if (isUnsafeSizeExpression(sizeExpr)) {
                    reportVulnerability(n, "Array creation with potentially unsafe size might lead to buffer overflow");
                }
            }
        }
        
        private boolean isUnsafeSizeExpression(Expression expr) {
            if (expr instanceof NameExpr) {
                String varName = ((NameExpr) expr).getNameAsString().toLowerCase();
                return varName.contains("input") || varName.contains("user") || varName.contains("size");
            }
            
            if (expr instanceof BinaryExpr) {
                BinaryExpr binExpr = (BinaryExpr) expr;
                return binExpr.getOperator() == BinaryExpr.Operator.PLUS || 
                       binExpr.getOperator() == BinaryExpr.Operator.MINUS ||
                       binExpr.getOperator() == BinaryExpr.Operator.MULTIPLY;
            }
            
            if (expr instanceof MethodCallExpr) {
                return true;
            }
            
            return false;
        }
        
        private void reportVulnerability(Node n, String message) {
            Optional<Position> position = n.getBegin();
            int lineNum = position.map(p -> p.line).orElse(-1);
            System.out.println("[VULNERABILITY] " + message + " at line " + lineNum);
            System.out.println("  Severity: MEDIUM");
            System.out.println("  Risk: Buffer overflow can lead to memory corruption or arbitrary code execution");
            vf++;
        }
    }
    
    // XSS Detection
    private static class XSSVisitor extends VoidVisitorAdapter<Void> {
        private int vf = 0;
    
        @Override
        public void visit(CompilationUnit cu, Void arg) {
            super.visit(cu, arg);
            System.out.println("XSS vulnerabilities found: " + vf);
        }
    
        @Override
        public void visit(MethodCallExpr n, Void arg) {
            super.visit(n, arg);
        
            String methodName = n.getNameAsString();
        
            if (methodName.equals("println") || methodName.equals("print") || 
                methodName.equals("write") || methodName.equals("append")) {
                checkForUnencodedOutput(n, "Direct output without encoding");
            }
        
            if (methodName.equals("getWriter") && n.getScope().isPresent() && 
                n.getScope().get().toString().contains("HttpServletResponse")) {
                reportVulnerability(n, "Direct response writing without output encoding");
            }
        }
    
        @Override
        public void visit(ObjectCreationExpr n, Void arg) {
            super.visit(n, arg);
        
            if (n.getTypeAsString().contains("ScriptEngine")) {
                reportVulnerability(n, "Script engine creation - potential code injection risk");
            }
        }
    
        private void checkForUnencodedOutput(MethodCallExpr n, String context) {
            n.getArguments().forEach(arg -> {
                String argString = arg.toString();
                if (argString.matches(".*(request\\.getParameter\\(|request\\.getHeader\\(|request\\.getQueryString\\().*") ||
                    argString.contains("+") && argString.matches(".*(request|session|param).*")) {
                    reportVulnerability(n, "Unencoded user input in output: " + context);
                }
            });
        }
    
        private void reportVulnerability(Node n, String message) {
            Optional<Position> position = n.getBegin();
            int lineNum = position.map(p -> p.line).orElse(-1);
            System.out.println("[VULNERABILITY] XSS risk: " + message + " at line " + lineNum);
            System.out.println("  Severity: HIGH");
            System.out.println("  Fix: Use proper output encoding (e.g., OWASP ESAPI, JSTL c:out)");
            vf++;
        }
    }

    // OS Command Injection Detection
    private static class OSCommandInjectionVisitor extends VoidVisitorAdapter<Void> {
        private int vf = 0;
    
        private static final Set<String> DANGEROUS_COMMANDS = Set.of(
            "cmd", "bash", "sh", "powershell", "zsh", "curl", "wget",
            "net", "reg", "sc", "systemctl", "osascript", "open"
        );
    
        private static final Set<Character> DANGEROUS_CHARS = Set.of(
            '&', '|', ';', '\n', '\r', '`', '$', '(', ')', '<', '>'
        );

        @Override
        public void visit(CompilationUnit cu, Void arg) {
            super.visit(cu, arg);
            System.out.println("OS Command Injection vulnerabilities found: " + vf);
        }

        @Override
        public void visit(MethodCallExpr n, Void arg) {
            super.visit(n, arg);
            String methodName = n.getNameAsString().toLowerCase();

            if (methodName.equals("exec") || methodName.equals("command")) {
            checkCommandInjection(n, methodName);
            }

            if (methodName.equals("start") && 
                n.getScope().isPresent() && 
                n.getScope().get().toString().toLowerCase().contains("processbuilder")) {
                reportVulnerability(n, "Potential OS command injection via ProcessBuilder.start()");
            }
        }
        
        private void checkCommandInjection(MethodCallExpr n, String methodName) {
            if (n.getScope().isPresent()) {
                Expression scope = n.getScope().get();
                String scopeStr = scope.toString().toLowerCase();

                if (scopeStr.contains("runtime") || scopeStr.contains("processbuilder")) {
                    n.getArguments().forEach(arg -> {
                        if (isSuspiciousArgument(arg)) {
                            String context = methodName.equals("exec") ? 
                                "Runtime.exec()" : "ProcessBuilder.command()";
                                reportVulnerability(n, 
                                "Potential OS command injection in " + context + 
                                " with untrusted input: " + arg.toString());
                        }
                    });
                }
            }
        }

        private boolean isSuspiciousArgument(Expression arg) {
            String argStr = arg.toString().toLowerCase();
        
            if (argStr.matches(".*(request\\.getParameter|\\.getQueryString|\\.getHeader|\\.getAttribute)\\(.*")) {
                return true;
            }
        
            if (DANGEROUS_COMMANDS.stream().anyMatch(argStr::contains)) {
                return true;
            }
        
            if (argStr.chars().anyMatch(c -> DANGEROUS_CHARS.contains((char)c))) {
                return true;
            }
        
            if (arg instanceof BinaryExpr) {
                BinaryExpr binaryExpr = (BinaryExpr) arg;
                if (binaryExpr.getOperator() == BinaryExpr.Operator.PLUS) {
                    return isSuspiciousArgument(binaryExpr.getLeft()) || 
                           isSuspiciousArgument(binaryExpr.getRight());
                }
            }
        
            if (argStr.matches(".*(\\$\\{|\\|\\||&&|;|`).*")) {
                return true;
            }
        
            return false;
        }

        private void reportVulnerability(Node n, String message) {
            Optional<Position> position = n.getBegin();
            int lineNum = position.map(p -> p.line).orElse(-1);
        
            System.out.println("\n[VULNERABILITY] OS Command Injection at line " + lineNum);
            System.out.println("  Issue: " + message);
            System.out.println("  Severity: CRITICAL");
            System.out.println("  Risk: Allows arbitrary command execution on:");
            System.out.println("    - Windows (cmd.exe, PowerShell)");
            System.out.println("    - Linux/macOS (bash, sh, zsh)");
            System.out.println("  Fixes:");
            System.out.println("    1. Use parameterized commands (ProcessBuilder with array)");
            System.out.println("    2. Validate against whitelisted characters");
            System.out.println("    3. Use built-in APIs instead of shell commands");
            System.out.println("    4. Escape all metacharacters");
        
            vf++;
        }
    }
    // End of the SASTanalyzer class
    // Add more visitor classes for other vulnerabilities as needed
}